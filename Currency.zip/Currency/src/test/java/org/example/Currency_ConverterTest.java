package org.example;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import  org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Currency_ConverterTest {
    private Currency_Converter converter;

    @BeforeEach
    public void setup() {
        Currency_DataBase database = new Currency_DataBase();
        converter = new Currency_Converter(database);
    }

    @Test
    @DisplayName("Convert ILS to USD")
    public void testConvertILSToUSD() {
        double amount = 100.0;
        double expectedUSDAmount = amount * Currency_DataBase.getILSToUSDRate();

        double actualUSDAmount = converter.convertILSToUSD(amount);

        assertEquals(expectedUSDAmount, actualUSDAmount, 0.001);
    }

    @Test
    @DisplayName("Convert USD to ILS")
    public void testConvertUSDtoILS() {
        double amount = 100.0;
        double expectedILSAmount = amount * Currency_DataBase.getUSDToILSRate();

        double actualILSAmount = converter.convertUSDtoILS(amount);

        assertEquals(expectedILSAmount, actualILSAmount, 0.001);
    }

    @Test
    @DisplayName("Convert EUR to USD")
    public void testConvertEURToUSD() {
        double amount = 100.0;
        double expectedUSDAmount = amount * Currency_DataBase.getEURToUSDRate();

        double actualUSDAmount = converter.convertEURToUSD(amount);

        assertEquals(expectedUSDAmount, actualUSDAmount, 0.001);
    }

    @Test
    @DisplayName("Convert USD to EUR")
    public void testConvertUSDtoEUR() {
        double amount = 100.0;
        double expectedEURAmount = amount * Currency_DataBase.getUSDToEURRate();

        double actualEURAmount = converter.convertUSDtoEUR(amount);

        assertEquals(expectedEURAmount, actualEURAmount, 0.001);
    }

    @Test
    @DisplayName("Convert ILS to JOD")
    public void testConvertILSToJOD() {
        double amount = 100.0;
        double expectedJODAmount = amount * Currency_DataBase.getILSToJODRate();

        double actualJODAmount = converter.convertILSToJOD(amount);

        assertEquals(expectedJODAmount, actualJODAmount, 0.001);
    }

    @Test
    @DisplayName("Convert JOD to ILS")
    public void testConvertJODToILS() {
        double amount = 100.0;
        double expectedILSAmount = amount * Currency_DataBase.getJODToILSRate();

        double actualILSAmount = converter.convertJODToILS(amount);

        assertEquals(expectedILSAmount, actualILSAmount, 0.001);
    }

    @ParameterizedTest
    @DisplayName("Convert ILS to USD (Parameterized)")
    @CsvSource({
            "100.0, 28.11",
            "200.0, 56.22",
            "50.0, 14.055000000000001",
    })
    public void testConvertILSToUSDParameterized(double amount, double expectedUSDAmount) {
        double actualUSDAmount = converter.convertILSToUSD(amount);

        assertEquals(expectedUSDAmount, actualUSDAmount, 0.001);
    }

    @ParameterizedTest
    @DisplayName("Convert USD to ILS (Parameterized)")
    @CsvSource({
            "100.0, 355.747",
            "200.0, 711.494",
            "50.0, 177.874"
    })
    public void testConvertUSDtoILSParameterized(double amount, double expectedILSAmount) {
        double actualILSAmount = converter.convertUSDtoILS(amount);

        assertEquals(expectedILSAmount, actualILSAmount, 0.001);
    }

    @ParameterizedTest
    @DisplayName("Convert EUR to USD (Parameterized)")
    @CsvSource({
            "100.0, 109.464",
            "200.0, 218.928",
            "50.0, 54.732"
    })
    public void testConvertEURToUSDParameterized(double amount, double expectedUSDAmount) {
        double actualUSDAmount = converter.convertEURToUSD(amount);

        assertEquals(expectedUSDAmount, actualUSDAmount, 0.001);
    }

    @ParameterizedTest
    @DisplayName("Convert USD to EUR (Parameterized)")
    @CsvSource({
            "100.0, 91.354",
            "200.0, 182.708",
            "50.0, 45.677"
    })
    public void testConvertUSDtoEURParameterized(double amount, double expectedEURAmount) {
        double actualEURAmount = converter.convertUSDtoEUR(amount);

        assertEquals(expectedEURAmount, actualEURAmount, 0.001);
    }

    @ParameterizedTest
    @DisplayName("Convert ILS to JOD (Parameterized)")
    @CsvSource({
            "100.0, 19.922",
            "200.0, 39.844",
            "50.0, 9.961"
    })
    public void testConvertILSToJODParameterized(double amount, double expectedJODAmount) {
        double actualJODAmount = converter.convertILSToJOD(amount);

        assertEquals(expectedJODAmount, actualJODAmount, 0.001);
    }

    @ParameterizedTest
    @DisplayName("Convert JOD to ILS (Parameterized)")
    @CsvSource({
            "100.0, 501.967",
            "200.0, 1003.934",
            "50.0, 250.984"
    })
    public void testConvertJODToILSParameterized(double amount, double expectedILSAmount) {
        double actualILSAmount = converter.convertJODToILS(amount);

        assertEquals(expectedILSAmount, actualILSAmount, 0.001);
    }


    @DisplayName("Convert ILS to USD (Empty)")
    @ParameterizedTest
    @EmptySource
    @ValueSource(strings = {"0.0", "10.5", "-5.7"}) // Additional non-empty values
    public void testConvertILSToUSDWithEmptyAmount(String inputAmount) {
        double amount;
        if (inputAmount.isEmpty()) {
            amount = 0.0; // Set a default value for an empty input
        } else {
            try {
                amount = Double.parseDouble(inputAmount);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Invalid input format: " + inputAmount);
            }
        }

        double expectedUSDAmount = amount * Currency_DataBase.getILSToUSDRate();
        double actualUSDAmount = converter.convertILSToUSD(amount);

        assertEquals(expectedUSDAmount, actualUSDAmount, 0.001);
    }


    @DisplayName("Convert USD to ILS (Empty)")
    @ParameterizedTest
    @NullSource
    @ValueSource(doubles = {0.0, 10.5, -5.7}) // Additional non-empty values
    public void testConvertUSDtoILSWithEmptyAmount(Double amount) {
        if (amount == null || amount.isNaN()) {
            // Skip the test case if amount is null or NaN
            return;
        }

        double expectedILSAmount = amount * Currency_DataBase.getUSDToILSRate();
        double actualILSAmount = converter.convertUSDtoILS(amount);

        assertEquals(expectedILSAmount, actualILSAmount, 0.001);
    }

    @ParameterizedTest
    @DisplayName("Convert ILS to USD (Null)")
    @NullSource
    @ValueSource(doubles = {0.0, 10.5, -5.7}) // Additional non-empty values
    public void testConvertILSToUSDWithNullAmount(Double amount) {
        if (amount == null || amount.isNaN()) {
            // Skip the test case if amount is null or NaN
            return;
        }

        double expectedILSAmount = amount * Currency_DataBase.getUSDToILSRate();
        double actualILSAmount = converter.convertUSDtoILS(amount);

        assertEquals(expectedILSAmount, actualILSAmount, 0.001);
    }


    @DisplayName("Convert USD to ILS (Null)")
    @ParameterizedTest
    @NullSource
    @ValueSource(doubles = {0, 10, -5.7}) // Additional non-null values
    public void testConvertUSDtoILSWithNullAmount(Double amount) {
        if (amount == null) {
            // Skip the test case if amount is null
            return;
        }

        double expectedILSAmount = amount * Currency_DataBase.getUSDToILSRate();
        double actualILSAmount = converter.convertUSDtoILS(amount);

        assertEquals(expectedILSAmount, actualILSAmount, 0.001);
    }
}
