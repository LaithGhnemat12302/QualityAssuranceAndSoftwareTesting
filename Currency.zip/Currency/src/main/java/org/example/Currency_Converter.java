package org.example;
import java.text.DecimalFormat;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Currency_Converter implements CurrencyInt {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Currency Converter");
        System.out.println("------------------");

        Currency_DataBase database = new Currency_DataBase();
        Currency_Converter converter = new Currency_Converter(database);

        int choice = 0; // Initialize choice to 0

        do {
            try {
                double amount;
                while (true) {
                    System.out.print("Enter amount: ");
                    String input = scanner.nextLine();
                    if (input.isEmpty()) {
                        System.out.println("Invalid input. Please enter a valid amount.");
                        continue;
                    }
                    try {
                        amount = Double.parseDouble(input);
                        if (amount % 1 == 0) {
                            System.out.println("Invalid input. Please enter a non-integer value for the amount.");
                            continue;
                        }
                        break; // Valid amount entered, break out of the loop
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input format. Please enter a valid number for the amount.");
                    }
                }

                System.out.println("Select conversion type:");
                System.out.println("1. From ILS to USD");
                System.out.println("2. From USD to ILS");
                System.out.println("3. From EUR to USD");
                System.out.println("4. From USD to EUR");
                System.out.println("5. From ILS to JOD");
                System.out.println("6. From JOD to ILS");
                System.out.println("7. Exit ");
                System.out.print("Enter your choice: ");

                while (true) {
                    try {
                        choice = scanner.nextInt();
                        scanner.nextLine(); // Consume the newline character after reading the choice
                        if (choice < 1 || choice > 7) {
                            System.out.println("Invalid choice. Please try again.");
                            continue;
                        }
                        break; // Valid choice entered, break out of the loop
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input. Please enter a valid number for the choice.");
                        scanner.nextLine(); // Clear the invalid input from the scanner
                    }
                }

                switch (choice) {
                    case 1:
                        converter.convertILSToUSD(amount);
                        break;
                    case 2:
                        converter.convertUSDtoILS(amount);
                        break;
                    case 3:
                        converter.convertEURToUSD(amount);
                        break;
                    case 4:
                        converter.convertUSDtoEUR(amount);
                        break;
                    case 5:
                        converter.convertILSToJOD(amount);
                        break;
                    case 6:
                        converter.convertJODToILS(amount);
                        break;
                    case 7:
                        System.out.println("Exiting the program...");
                        break;
                }
            } catch (Exception e) {
                System.out.println("An error occurred: " + e.getMessage());
            }
        } while (choice != 7);

        scanner.close();
    }

    private Currency_DataBase database;

    public Currency_Converter(Currency_DataBase database) {
        this.database = database;
    }

    @Override
    public double convertILSToUSD(double amount) {
        double usdAmount = amount * database.getILSToUSDRate();
        System.out.println("Converted amount: " + formatAmount(usdAmount) + " USD");
        return usdAmount;
    }

    @Override
    public double convertUSDtoILS(double amount) {
        double ilsAmount = amount * database.getUSDToILSRate();
        System.out.println("Converted amount: " + formatAmount(ilsAmount) + " ILS");
        return ilsAmount;
    }

    @Override
    public double convertEURToUSD(double amount) {
        double usdAmount = amount * database.getEURToUSDRate();
        System.out.println("Converted amount: " + formatAmount(usdAmount) + " USD");
        return usdAmount;
    }

    @Override
    public double convertUSDtoEUR(double amount) {
        double eurAmount = amount * database.getUSDToEURRate();
        System.out.println("Converted amount: " + formatAmount(eurAmount) + " EUR");
        return eurAmount;
    }

    @Override
    public double convertILSToJOD(double amount) {
        double jodAmount = amount * database.getILSToJODRate();
        System.out.println("Converted amount: " + formatAmount(jodAmount) + " JOD");
        return jodAmount;
    }

    @Override
    public double convertJODToILS(double amount) {
        double ilsAmount = amount * database.getJODToILSRate();
        System.out.println("Converted amount: " + formatAmount(ilsAmount) + " ILS");
        return ilsAmount;
    }

    private String formatAmount(double amount) {
        DecimalFormat decimalFormat = new DecimalFormat("#,####0.0000");
        return decimalFormat.format(amount);
    }
}