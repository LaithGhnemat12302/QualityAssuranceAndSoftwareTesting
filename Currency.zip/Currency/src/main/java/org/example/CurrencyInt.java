package org.example;

public interface CurrencyInt {
    double convertILSToUSD(double amount);
    double convertUSDtoILS(double amount);
    double convertEURToUSD(double amount);
    double convertUSDtoEUR(double amount);
    double convertILSToJOD(double amount);
    double convertJODToILS(double amount);
}