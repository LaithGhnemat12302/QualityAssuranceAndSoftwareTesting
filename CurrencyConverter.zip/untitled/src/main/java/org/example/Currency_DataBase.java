package org.example;

public class Currency_DataBase implements CurrencyInt {
    private static final double ILS_TO_USD_RATE = 0.2811;
    private static final double USD_TO_ILS_RATE = 3.55747;
    private static final double EUR_TO_USD_RATE = 1.09464;
    private static final double USD_TO_EUR_RATE = 0.91354;
    private static final double ILS_TO_JOD_RATE = 0.19922;
    private static final double JOD_TO_ILS_RATE = 5.01967;

    public double getILSToUSDRate() {
        return ILS_TO_USD_RATE;
    }

    public double getUSDToILSRate() {
        return USD_TO_ILS_RATE;
    }

    public double getEURToUSDRate() {
        return EUR_TO_USD_RATE;
    }

    public double getUSDToEURRate() {
        return USD_TO_EUR_RATE;
    }

    public double getILSToJODRate() {
        return ILS_TO_JOD_RATE;
    }

    public double getJODToILSRate() {
        return JOD_TO_ILS_RATE;
    }

    // Implement the interface methods
    @Override
    public double convertILSToUSD(double amount) {
        return amount * getILSToUSDRate();
    }

    @Override
    public double convertUSDtoILS(double amount) {
        return amount * getUSDToILSRate();
    }

    @Override
    public double convertEURToUSD(double amount) {
        return amount * getEURToUSDRate();
    }

    @Override
    public double convertUSDtoEUR(double amount) {
        return amount * getUSDToEURRate();
    }

    @Override
    public double convertILSToJOD(double amount) {
        return amount * getILSToJODRate();
    }

    @Override
    public double convertJODToILS(double amount) {
        return amount * getJODToILSRate();
    }
}
