package org.example;
import java.text.DecimalFormat;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Currency_Converter implements CurrencyInt {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Currency Converter");
        System.out.println("------------------");

        CurrencyInt database = new Currency_DataBase();
        Currency_Converter converter = new Currency_Converter(database);

        int choice = 0; // Initialize choice to 0

        do {
            try {
                System.out.println("Please enter the amount:");
                double amount = scanner.nextDouble();

                System.out.println("Please select an option:");
                System.out.println("1. Convert ILS to USD");
                System.out.println("2. Convert USD to ILS");
                System.out.println("3. Convert EUR to USD");
                System.out.println("4. Convert USD to EUR");
                System.out.println("5. Convert ILS to JOD");
                System.out.println("6. Convert JOD to ILS");
                System.out.println("7. Exit");

                choice = scanner.nextInt();

                switch (choice) {
                    case 1 -> converter.convertILSToUSD(amount);
                    case 2 -> converter.convertUSDtoILS(amount);
                    case 3 -> converter.convertEURToUSD(amount);
                    case 4 -> converter.convertUSDtoEUR(amount);
                    case 5 -> converter.convertILSToJOD(amount);
                    case 6 -> converter.convertJODToILS(amount);
                    case 7 -> System.out.println("Exiting the program...");
                    default -> System.out.println("Invalid choice. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // Clear the input buffer
            } catch (Exception e) {
                System.out.println("An error occurred: " + e.getMessage());
            }
        } while (choice != 7);

        scanner.close();
    }

    private final CurrencyInt database;

    public Currency_Converter(CurrencyInt database) {
        this.database = database;
    }

    @Override
    public double getILSToUSDRate() {
        return database.getILSToUSDRate();
    }

    @Override
    public double getUSDToILSRate() {
        return database.getUSDToILSRate();
    }

    @Override
    public double getEURToUSDRate() {
        return database.getEURToUSDRate();
    }

    @Override
    public double getUSDToEURRate() {
        return database.getUSDToEURRate();
    }

    @Override
    public double getILSToJODRate() {
        return database.getILSToJODRate();
    }

    @Override
    public double getJODToILSRate() {
        return database.getJODToILSRate();
    }

    @Override
    public double convertILSToUSD(double amount) {
        double usdAmount = amount * getILSToUSDRate();
        System.out.println("Converted amount: " + formatAmount(usdAmount) + " USD");
        return usdAmount;
    }

    @Override
    public double convertUSDtoILS(double amount) {
        double ilsAmount = amount * getUSDToILSRate();
        System.out.println("Converted amount: " + formatAmount(ilsAmount) + " ILS");
        return ilsAmount;
    }

    @Override
    public double convertEURToUSD(double amount) {
        double usdAmount = amount * getEURToUSDRate();
        System.out.println("Converted amount: " + formatAmount(usdAmount) + " USD");
        return usdAmount;
    }

    @Override
    public double convertUSDtoEUR(double amount) {
        double eurAmount = amount * getUSDToEURRate();
        System.out.println("Converted amount: " + formatAmount(eurAmount) + " EUR");
        return eurAmount;
    }

    @Override
    public double convertILSToJOD(double amount) {
        double jodAmount = amount * getILSToJODRate();
        System.out.println("Converted amount: " + formatAmount(jodAmount) + " JOD");
        return jodAmount;
    }

    @Override
    public double convertJODToILS(double amount) {
        double ilsAmount = amount * getJODToILSRate();
        System.out.println("Converted amount: " + formatAmount(ilsAmount) + " ILS");
        return ilsAmount;
    }

    private String formatAmount(double amount) {
        DecimalFormat decimalFormat = new DecimalFormat("#,####0.0000");
        return decimalFormat.format(amount);
    }
}
