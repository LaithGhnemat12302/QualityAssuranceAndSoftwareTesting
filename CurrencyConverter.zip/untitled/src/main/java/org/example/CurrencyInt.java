package org.example;

public interface CurrencyInt {
    double getILSToUSDRate();
    double getUSDToILSRate();
    double getEURToUSDRate();
    double getUSDToEURRate();
    double getILSToJODRate();
    double getJODToILSRate();

    double convertILSToUSD(double amount);
    double convertUSDtoILS(double amount);
    double convertEURToUSD(double amount);
    double convertUSDtoEUR(double amount);
    double convertILSToJOD(double amount);
    double convertJODToILS(double amount);
}
