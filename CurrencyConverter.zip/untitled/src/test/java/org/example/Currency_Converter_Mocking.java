package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

public class Currency_Converter_Mocking {
    private CurrencyInt database;
    private Currency_Converter converter;

    @BeforeEach
    public void setUp() {
        database = mock(CurrencyInt.class);
        converter = new Currency_Converter(database);
    }

    @Test
    public void testConvertILSToUSD() {
        double ilsToUsdRate = 0.2811;
        double amount = 100.0;
        double expectedAmount = amount * ilsToUsdRate;

        when(database.getILSToUSDRate()).thenReturn(ilsToUsdRate);

        double result = converter.convertILSToUSD(amount);

        assertEquals(expectedAmount, result);
        verify(database).getILSToUSDRate();
    }

    @Test
    public void testConvertILSToUSD_ThrowException() {
        // Set up mock behavior to throw an exception
        doThrow(new RuntimeException("Database connection error")).when(database).getILSToUSDRate();

        double amount = 100.0;

        // Expect the RuntimeException to be thrown
        assertThrows(RuntimeException.class, () -> converter.convertILSToUSD(amount));
    }


    @Test
    public void testConvertILSToUSD_DoAnswer() {
        // Set up mock behavior to provide a custom answer
        double customRate = 2.0;
        when(database.getILSToUSDRate()).thenAnswer(invocation -> customRate);

        double amount = 100.0;
        double expectedAmount = amount * customRate; // Custom answer: rate * 2

        double result = converter.convertILSToUSD(amount);

        assertEquals(expectedAmount, result);
    }



    @Test
    public void testConvertUSDtoILS() {
        double usdToIlsRate = 3.55747;
        double amount = 100.0;
        double expectedAmount = amount * usdToIlsRate;

        when(database.getUSDToILSRate()).thenReturn(usdToIlsRate);

        double result = converter.convertUSDtoILS(amount);

        assertEquals(expectedAmount, result);
        verify(database).getUSDToILSRate();
    }

    @Test
    public void testConvertEURToUSD() {
        double eurToUsdRate = 1.09464;
        double amount = 100.0;
        double expectedAmount = amount * eurToUsdRate;

        when(database.getEURToUSDRate()).thenReturn(eurToUsdRate);

        double result = converter.convertEURToUSD(amount);

        assertEquals(expectedAmount, result);
        verify(database).getEURToUSDRate();
    }

    @Test
    public void testConvertUSDtoEUR() {
        double usdToEurRate = 0.91354;
        double amount = 100.0;
        double expectedAmount = amount * usdToEurRate;

        when(database.getUSDToEURRate()).thenReturn(usdToEurRate);

        double result = converter.convertUSDtoEUR(amount);

        assertEquals(expectedAmount, result);
        verify(database).getUSDToEURRate();
    }

    @Test
    public void testConvertILSToJOD() {
        double ilsToJodRate = 0.19922;
        double amount = 100.0;
        double expectedAmount = amount * ilsToJodRate;

        when(database.getILSToJODRate()).thenReturn(ilsToJodRate);

        double result = converter.convertILSToJOD(amount);

        assertEquals(expectedAmount, result);
        verify(database).getILSToJODRate();
    }

    @Test
    public void testConvertJODToILS() {
        double jodToIlsRate = 5.01967;
        double amount = 100.0;
        double expectedAmount = amount * jodToIlsRate;

        when(database.getJODToILSRate()).thenReturn(jodToIlsRate);

        double result = converter.convertJODToILS(amount);

        assertEquals(expectedAmount, result);
        verify(database).getJODToILSRate();
    }
}
